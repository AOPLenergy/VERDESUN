import Contact from './components/Contact';
import Features from './components/Features';
import Hero from './components/Hero';
import Impact from './components/Impact';
import Navbar from './components/Navbar';
import Solutions from './components/Solutions';

function App() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <main>
        <Hero />
        <Solutions />
        <Features />
        <Impact />
        <Contact />
      </main>
    </div>
  );
}

export default App;