import { Leaf, Menu, X } from 'lucide-react';
import { useState } from 'react';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="fixed w-full bg-white z-50 border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-14 items-center">
          <div className="flex items-center space-x-8">
            <div className="flex items-center">
              <Leaf className="h-6 w-6 text-blue-600" />
              <span className="ml-2 text-lg font-semibold">Verdesun</span>
            </div>
            <div className="hidden md:flex space-x-6">
              <a href="#solutions" className="text-sm text-gray-700 hover:text-blue-600">Solutions</a>
              <a href="#features" className="text-sm text-gray-700 hover:text-blue-600">Features</a>
              <a href="#impact" className="text-sm text-gray-700 hover:text-blue-600">Impact</a>
              <a href="#contact" className="text-sm text-gray-700 hover:text-blue-600">Contact</a>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <button className="hidden md:block text-sm text-gray-700 hover:text-blue-600">Sign in</button>
            <button className="bg-blue-600 text-white text-sm px-4 py-2 rounded-sm hover:bg-blue-700">
              Get started
            </button>
            <button className="md:hidden" onClick={() => setIsOpen(!isOpen)}>
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {isOpen && (
        <div className="md:hidden border-t border-gray-200">
          <div className="px-4 py-2 space-y-1">
            <a href="#solutions" className="block py-2 text-sm text-gray-700 hover:text-blue-600">Solutions</a>
            <a href="#features" className="block py-2 text-sm text-gray-700 hover:text-blue-600">Features</a>
            <a href="#impact" className="block py-2 text-sm text-gray-700 hover:text-blue-600">Impact</a>
            <a href="#contact" className="block py-2 text-sm text-gray-700 hover:text-blue-600">Contact</a>
          </div>
        </div>
      )}
    </nav>
  );
}