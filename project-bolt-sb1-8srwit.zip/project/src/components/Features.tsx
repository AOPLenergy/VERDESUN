import { Activity, Box, Globe, LineChart, RefreshCcw, ShieldCheck } from 'lucide-react';

export default function Features() {
  const features = [
    {
      icon: <LineChart className="h-6 w-6 text-green-600" />,
      title: "AI-Driven Analytics",
      description: "Advanced machine learning algorithms analyze your supply chain for optimization opportunities."
    },
    {
      icon: <Globe className="h-6 w-6 text-green-600" />,
      title: "Global Impact",
      description: "Track and reduce your carbon footprint across international operations."
    },
    {
      icon: <Activity className="h-6 w-6 text-green-600" />,
      title: "Real-time Monitoring",
      description: "Continuous monitoring and instant alerts for carbon reduction opportunities."
    },
    {
      icon: <Box className="h-6 w-6 text-green-600" />,
      title: "Smart Inventory",
      description: "Optimize inventory management to reduce waste and emissions."
    },
    {
      icon: <RefreshCcw className="h-6 w-6 text-green-600" />,
      title: "Automated Optimization",
      description: "Self-learning systems that continuously improve decarbonization strategies."
    },
    {
      icon: <ShieldCheck className="h-6 w-6 text-green-600" />,
      title: "Compliance Ready",
      description: "Stay ahead of environmental regulations with built-in compliance tools."
    }
  ];

  return (
    <section id="features" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">
            Powerful Features for Sustainable Commerce
          </h2>
          <p className="mt-4 text-lg text-gray-600">
            Our comprehensive suite of tools helps you achieve your sustainability goals
          </p>
        </div>

        <div className="mt-20 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((feature, index) => (
            <div key={index} className="relative group">
              <div className="absolute -inset-0.5 bg-gradient-to-r from-green-600 to-emerald-600 rounded-lg blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
              <div className="relative p-6 bg-white ring-1 ring-gray-900/5 rounded-lg leading-none flex items-top justify-start space-x-6">
                <div className="space-y-6">
                  <div className="flex items-center space-x-4">
                    {feature.icon}
                    <h3 className="text-lg font-semibold text-gray-900">{feature.title}</h3>
                  </div>
                  <p className="text-gray-600">{feature.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}