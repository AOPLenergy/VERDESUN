export default function Impact() {
  return (
    <section id="impact" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">
            Making a Real Impact
          </h2>
          <p className="mt-4 text-lg text-gray-600">
            See how our solutions are helping businesses achieve their sustainability goals
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="relative h-96 rounded-xl overflow-hidden">
            <img
              src="https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?auto=format&fit=crop&q=80"
              alt="Sustainable business"
              className="absolute inset-0 w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent">
              <div className="absolute bottom-0 left-0 right-0 p-8">
                <div className="text-white">
                  <p className="text-sm font-semibold text-green-400">Case Study</p>
                  <h3 className="mt-2 text-2xl font-bold">Global Retail Chain</h3>
                  <p className="mt-2">Reduced carbon emissions by 45% within first year</p>
                </div>
              </div>
            </div>
          </div>

          <div className="relative h-96 rounded-xl overflow-hidden">
            <img
              src="https://images.unsplash.com/photo-1466611653911-95081537e5b7?auto=format&fit=crop&q=80"
              alt="Sustainable technology"
              className="absolute inset-0 w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent">
              <div className="absolute bottom-0 left-0 right-0 p-8">
                <div className="text-white">
                  <p className="text-sm font-semibold text-green-400">Success Story</p>
                  <h3 className="mt-2 text-2xl font-bold">E-commerce Pioneer</h3>
                  <p className="mt-2">Achieved carbon neutrality in logistics operations</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-20 grid grid-cols-2 gap-8 md:grid-cols-4">
          <div className="text-center">
            <h3 className="text-4xl font-bold text-green-600">45%</h3>
            <p className="mt-2 text-gray-600">Average Carbon Reduction</p>
          </div>
          <div className="text-center">
            <h3 className="text-4xl font-bold text-green-600">1000+</h3>
            <p className="mt-2 text-gray-600">Businesses Helped</p>
          </div>
          <div className="text-center">
            <h3 className="text-4xl font-bold text-green-600">2.5M</h3>
            <p className="mt-2 text-gray-600">Tons CO₂ Saved</p>
          </div>
          <div className="text-center">
            <h3 className="text-4xl font-bold text-green-600">98%</h3>
            <p className="mt-2 text-gray-600">Client Satisfaction</p>
          </div>
        </div>
      </div>
    </section>
  );
}