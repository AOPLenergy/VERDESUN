import { Battery, Car, Factory, Leaf, Lightbulb, Recycle, Sprout, Wind } from 'lucide-react';

const categories = [
  {
    icon: <Leaf className="h-6 w-6" />,
    title: "Renewable Energy",
    description: "Complete solar and wind energy solutions",
    products: [
      "Solar PV Modules",
      "Solar Inverters",
      "Wind Turbines",
      "Energy Storage Systems",
      "Solar Water Heaters"
    ]
  },
  {
    icon: <Factory className="h-6 w-6" />,
    title: "Sustainable Construction",
    description: "Eco-friendly building materials",
    products: [
      "Low Carbon Cement",
      "Recycled Steel",
      "Green Roofing Systems",
      "Bio-based Insulation",
      "Sustainable Wood Composites"
    ]
  },
  {
    icon: <Lightbulb className="h-6 w-6" />,
    title: "Energy Efficiency",
    description: "Smart energy management solutions",
    products: [
      "LED Lighting Solutions",
      "Smart Thermostats",
      "Energy Monitors",
      "HVAC Systems",
      "Heat Pumps"
    ]
  },
  {
    icon: <Car className="h-6 w-6" />,
    title: "Electric Mobility",
    description: "EV infrastructure and solutions",
    products: [
      "EV Charging Stations",
      "Battery Systems",
      "E-Bikes",
      "Fleet Management",
      "Charging Software"
    ]
  },
  {
    icon: <Recycle className="h-6 w-6" />,
    title: "Carbon Capture",
    description: "Advanced carbon reduction technology",
    products: [
      "Industrial Capture Units",
      "Direct Air Capture",
      "Biochar Products",
      "Carbon Storage",
      "Monitoring Systems"
    ]
  },
  {
    icon: <Sprout className="h-6 w-6" />,
    title: "Agricultural Solutions",
    description: "Sustainable farming technologies",
    products: [
      "Precision Farming Tools",
      "Organic Fertilizers",
      "Smart Irrigation",
      "Soil Monitors",
      "Crop Analytics"
    ]
  },
  {
    icon: <Wind className="h-6 w-6" />,
    title: "Water Management",
    description: "Water conservation and treatment",
    products: [
      "Treatment Systems",
      "Recycling Units",
      "Smart Meters",
      "Filtration",
      "Conservation Tools"
    ]
  },
  {
    icon: <Battery className="h-6 w-6" />,
    title: "Smart Technology",
    description: "AI-powered sustainability tools",
    products: [
      "Energy Platforms",
      "IoT Sensors",
      "Smart Grids",
      "Automation Systems",
      "Analytics Software"
    ]
  }
];

export default function Solutions() {
  return (
    <section id="solutions" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">
            Comprehensive Decarbonization Solutions
          </h2>
          <p className="mt-4 text-lg text-gray-600">
            Explore our range of sustainable products and solutions
          </p>
        </div>

        <div className="mt-20 grid grid-cols-1 gap-12 lg:grid-cols-2">
          {categories.map((category, index) => (
            <div key={index} className="relative group">
              <div className="absolute -inset-0.5 bg-gradient-to-r from-green-600 to-emerald-600 rounded-lg blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
              <div className="relative p-8 bg-white ring-1 ring-gray-900/5 rounded-lg leading-none">
                <div className="flex items-center space-x-4 mb-6">
                  <div className="p-3 bg-green-100 rounded-lg">
                    {category.icon}
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900">{category.title}</h3>
                    <p className="text-gray-600">{category.description}</p>
                  </div>
                </div>
                
                <ul className="space-y-3">
                  {category.products.map((product, productIndex) => (
                    <li key={productIndex} className="flex items-center">
                      <div className="w-1.5 h-1.5 bg-green-600 rounded-full mr-3"></div>
                      <span className="text-gray-700">{product}</span>
                    </li>
                  ))}
                </ul>

                <button className="mt-6 inline-flex items-center text-green-600 hover:text-green-700">
                  Learn more
                  <svg className="ml-2 w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}